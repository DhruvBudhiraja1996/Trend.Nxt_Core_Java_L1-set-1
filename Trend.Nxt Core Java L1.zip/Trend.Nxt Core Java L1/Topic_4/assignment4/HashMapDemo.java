package assignment4;
import java.util.HashMap; 
import java.util.Map;
import java.util.Scanner; 
public class HashMapDemo {
	public static void main(String[] args)  
    { 
      int original=0;
      String phoneNo="";
        HashMap<String, String> map = new HashMap<>(); 
	      Scanner in = new Scanner(System.in);
	      String Name="";
	      boolean exit=false;
		    while(!exit) {
	      System.out.println("Enter 1: add Number 2: get phone Number 3: all contacts");
	      
	      original = in.nextInt();
	      if(original==1) {
	    	  System.out.println("Enter name");
	    	  while(!in.hasNext());
	    	  in.nextLine();
	    	  Name=in.next();
	    	  System.out.println("Enter Phone Number");
	    	  while(!(in.hasNext()));
	    	  in.nextLine();
	    	  phoneNo = in.next();
	    	  
	    	  System.out.println(phoneNo);
	    	  addNumber(map, Name, phoneNo);
	    	  
	      }else if(original==2) {
	    	  System.out.println("Enter name");
	    	  while(!in.hasNext());
	    	  in.nextLine();
	    	  Name=in.next();
	    	  
	    	  System.out.println(getNumber(map, Name));
	      }
	      else if(original==3) {
	    	  print(map);
	      }
	      else {
	    	  System.out.println("wrong input");}
	      System.out.println("Do you want to exit(yes/no)");
	      while(!in.hasNext());
	      in.nextLine();
	      Name=in.next();
	      if(Name.equalsIgnoreCase("yes")) {
	    	   exit=true;}
	      }
	      
    } 
      public static void addNumber(Map<String, String> map, String name, String phoneNo) {
    	  map.put(name, phoneNo);	  
      }
      
      public static String getNumber(Map<String, String> map, String name) {
    	  String phoneNo;
    	  if (map.containsKey(name))  
          { 
              phoneNo = map.get(name); 
             
          } else {System.out.println("Phone number is not available");
          phoneNo="";
          }
    	  return phoneNo;
      }
    public static void print(Map<String, String> map)  
    { 
        if (map.isEmpty())  
        { 
            System.out.println("map is empty"); 
        } 
          
        else
        { 
            System.out.println(map); 
        } 
    } 
}
