package assignment3;

public class IndexException {
 public static void main(String[] args) {
	 if(args.length >0) 
	 {
		 try {
			 int sum=0;
			 for(int i=0;i<5;i++)
			 sum += Integer.parseInt(args[i]);
			 int avg= sum/5;
			 System.out.println("Average is "+avg);
		 }
		 catch(ArrayIndexOutOfBoundsException e) {
			 System.out.println(e);
		 }
	 }
	
 }
}
