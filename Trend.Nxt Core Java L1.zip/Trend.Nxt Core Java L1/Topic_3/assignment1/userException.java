package assignment1;

public class userException {
	public static void main(String[] args) {
		try {
			if(args!= null) {
				int age=Integer.parseInt(args[0]);
				if(!((age >17)&&(age<60)))
						throw new myException();
			}
			
		}
		catch(myException e) {
			System.out.println(e);
		}
		
	}

}
