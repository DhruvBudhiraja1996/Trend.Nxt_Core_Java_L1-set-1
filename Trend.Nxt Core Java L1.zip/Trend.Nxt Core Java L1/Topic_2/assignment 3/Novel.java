package assignment3;

public class Novel extends Book{
String author;
	Novel(String isbn, String title, String author, int price) {
		super(isbn, title, price);
		this.author=author;
		// TODO Auto-generated constructor stub
	}
	 public void displayDetails() {
		 super.displayDetails();
		 System.out.println(" Author name : "+this.author);
	 }



}
