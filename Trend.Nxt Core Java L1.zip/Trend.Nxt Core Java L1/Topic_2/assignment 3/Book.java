package assignment3;

public class Book {
	public String isbn;
	public String title;

	public int price;
 Book(String isbn, String title, int price){
		this.isbn=isbn;
		this.title=title;

		this.price=price;

	}
 public void displayDetails() {
	 System.out.print("isbn: "+this.isbn +", Book Title :"+this.title+", price :"+this.price);

 }




	public static void main(String[] args) {
	Novel n1=new Novel("12345678","nothing","something",500);
	n1.displayDetails();
	Magazine m1=new Magazine("144478","nothing1","something1",1000);
	n1.displayDetails();
	m1.displayDetails();

}

}
