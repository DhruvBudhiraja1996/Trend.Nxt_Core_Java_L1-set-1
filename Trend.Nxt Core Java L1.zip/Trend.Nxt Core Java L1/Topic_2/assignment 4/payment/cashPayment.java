package payment;

class cashPayment extends Payment
{
    void paymentDetails()
    {
        super.paymentDetails();
        System.out.println("The payment is in cash");
    }
}
