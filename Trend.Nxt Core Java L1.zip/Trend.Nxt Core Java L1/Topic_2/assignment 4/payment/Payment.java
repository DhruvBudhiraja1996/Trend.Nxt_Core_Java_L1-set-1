package payment;

class Payment {

	private	double amt;
	public void set(double b)
		{
		    amt=b;
		}
	public double get()
	{
	    return amt;
	}
	void paymentDetails()
	{
	    System.out.println("The amount is "+amt);
	}
}