package payment;

class CreditCardPayment extends Payment
{
    String name;
    String exp;
    String no;
    double am;
    CreditCardPayment(String n, String e, String nn)
    {
        name=n;
        exp=e;
        no=nn;
    }

    void paymentDetails()
    {
        
        super.paymentDetails();
        System.out.println("The name is="+ name);
        System.out.println("The exp is="+ exp);
        System.out.println("The no is="+ no);
    }
}