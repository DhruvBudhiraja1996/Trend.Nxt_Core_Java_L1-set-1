import java.util.*;
import java.lang.*;
import java.io.*;

class Assignment4
{
	public static void main (String[] args) throws java.lang.Exception
	{
	    System.out.println("*****************Assignment 4:*******************");
	  
	        System.out.println("input the Month Number");
	        Scanner input = new Scanner(System.in);
	        int mon = input.nextInt();
	        String monthName="";
	        switch(mon)
	        {
	        case 1: monthName="January";
	        break;
	        case 2: monthName="february";
	        break;
	        case 3: monthName="March";
	        break;
	        case 4: monthName="April";
	        break;
	        case 5: monthName="May";
	        break;
	        case 6: monthName="June";
	        break;
	        case 7: monthName="July";
	        break;
	        case 8: monthName="August";
	        break;
	        case 9: monthName="September";
	        break;
	        case 10: monthName="October";
	        break;
	        case 11: monthName="November";
	        break;
	        case 12: monthName="December";
	        break;
	        default: System.out.println("enter value between 1 to 12 only");
	        break;
	        
	        }
	        System.out.println("Month Name:"+monthName);

	}
}
