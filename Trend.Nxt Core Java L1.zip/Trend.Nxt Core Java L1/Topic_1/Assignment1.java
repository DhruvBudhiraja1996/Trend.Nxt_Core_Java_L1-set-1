import java.util.*;
import java.lang.*;
import java.io.*;

class Assignment1
{
	public static void main (String[] args) throws java.lang.Exception
	{
     	System.out.println("****************Assignment 1:****************");
		String name= "Dhruv Budhiraja";
		System.out.println("Welcome to Java Programming");
		System.out.println(name);

	}
}
