import java.util.*;
import java.lang.*;
import java.io.*;

class Assignment2
{
	public static void main (String[] args) throws java.lang.Exception
	{
        System.out.println("****************Assignment 2 :****************");
		int a=5;
		int b=8;
		int c=6;
		int d=55;
		int e=9;
		int f=20;
		int g=3;
		int h=15;
		int i=2;
		System.out.println(" -5 + 8 * 6 ="+ (-a+b*c));
		System.out.println("(55+9) % 9 ="+((d+e)%e));
		System.out.println("20 + -3*5 / 8 ="+(f+(-g)*a/b));
		System.out.println(" 5 + 15 / 3 * 2 -8 % 3 ="+(a+h/g*i-b%g));
	}
}
