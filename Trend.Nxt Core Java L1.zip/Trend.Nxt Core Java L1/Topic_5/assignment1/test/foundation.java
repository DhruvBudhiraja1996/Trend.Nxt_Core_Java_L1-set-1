
package assignment1.test;

public class foundation {
private int var1;
int var2;
protected int var3;
public int var4;
}
